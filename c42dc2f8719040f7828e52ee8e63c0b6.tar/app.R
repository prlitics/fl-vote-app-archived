#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(sf)
library(leaflet)
library(dplyr)
library(lwgeom)
library(shinybusy)
library(shinycssloaders)

homeicon <- makeIcon(
    iconUrl = "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-orange.png",
    iconWidth = 25, iconHeight = 41,
    iconAnchorX = 12, iconAnchorY = 41,
    shadowUrl = "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
    shadowWidth = 41, shadowHeight = 41,
    shadowAnchorX = 4, shadowAnchorY = 62,
    popupAnchorX = 1, popupAnchorY = -34
)

#gps_points <- read.csv("D:/Data/2020fldropboxes.csv")
gps_points <- read.csv("./Data/points.rds")
fl_cnty_bdrs <- readRDS("./Data/counties.rds")


# Define UI for application that draws a histogram
ui <- navbarPage(title = "Florida Ballot Drop Off and Early Voting Locations",
    tabPanel("Home", add_busy_spinner(spin = "fading-circle"),
             titlePanel(h1("Florida Ballot Drop-Off and Early Voting Locator", align = "center")),
             h3(em("Make a plan. Vote."),align = "center"),
             HTML('<center><img src ="https://i.imgur.com/5Ksq7d8.png", width = "30%" ></center>'),
             h4("This application is meant to provide Florida voters with 3 ways to find ballot drop-off and early voting locations near where they're registered:"),
             HTML("<strong>1. Filter by County:</strong> Select the county that you are registered to vote in, filter locations by whether or not they are both a ballot drop-off and early vote location or whether they are simply a ballot drop-off location.<br/><strong>2. Zoom-in on the whole State:</strong> Take a look at the whole state and zoom in manually.<br/><strong>3. Click and Filter [EXPERIMENTAL]:</strong> Click on a zoomable map of the state at get the locations in the county you clicked on as well as the distance the selected precincts are (as the crow flies) from the point."),
             br(),
             h4("In all cases, you can click on the points to learn the location's name, address, hours, and dates of availability. You can also see whether it is both an early vote location and ballot drop-off point or just a ballot-drop-off point."),
             HTML("<h4>This app is a collaborative project, made by volunteers, in service to Florida voters to help them vote this November. <strong>It should not be taken as a replacement for information provided by State and County election officials.</strong> Click on the 'about' tab to learn more and see the collaborators.")),             
    
    
    tabPanel("Select Your County",
             titlePanel(h1("Select your county from the list to see the early voting and ballot drop-off locations for your county.", align = "center")),
             p("Click on the icons to learn more about that location."),
             sidebarPanel(selectInput("county", "Choose the County You are Registered in:",
                                      choices = sort(unique(fl_cnty_bdrs$name))),
                          checkboxGroupInput(inputId =  "check1", label = "Location Type", choices = unique(gps_points$type), selected = unique(gps_points$type))),
             mainPanel(leafletOutput("map2")%>% withSpinner(type = 1, color = "#0dc5c1"))),
        tabPanel("Statewide Zoom",
             titlePanel(h1("Zoom in to find ballot drop-off and early voting locations throughout the state.", align = "center")),
             h3("Markers will appear as you zoom in on the map. Click on the marker for details about that location.", align = "center"),
             mainPanel(leafletOutput("map1")%>% withSpinner(type = 1, color = "#0dc5c1"))),
    tabPanel("Click and Filter\n(EXPERIMENTAL)",
             titlePanel(h1("Find Distance to Precincts based on Where you Click", align = "center")),
             h3("Click on the map and it will show you locations based on the county you clicked on.", align = "center"),
             h4("Hover over the points to see the distance 'as the crow flies' (in miles) between your selected point and that location", align = "center"),
             h4(em("You can click multiple times and the map will update based on your new input. Click the reset button to return to the full state view."), align = "center"),
             sidebarPanel(actionButton("submit", "Reset Map", icon = icon("sync-alt")),
                          checkboxGroupInput(inputId =  "check3", label = "Location Type", choices = unique(gps_points$type), selected = unique(gps_points$type))),
             mainPanel(leafletOutput("map3")%>% withSpinner(type = 1, color = "#0dc5c1"))
             
             ),
    tabPanel("About",
             h1("Collaborators:", align = "center"),
             HTML("<h3><strong>Project Lead:</strong><br/></h3><h4><a href = 'https://twitter.com/PRLPoliSci'> Peter Licari, PhD</a>"),
             HTML("<h3><strong>Other Contributors:<br/></strong></h3><h4><a href = 'https://twitter.com/electionsmith'> Dan Smith, PhD</a>,<a href = 'https://twitter.com/_hannahjacobss'> Hannah Jacobs</a>,<a href = 'https://www.linkedin.com/in/haley-g-3b64391b4/'> Haley Gonzalez</a>,<a href = 'https://github.com/adr27/'> Adriel Nittala</a>,<a href = 'https://www.linkedin.com/in/danielapsanchezp/'> Daniela Sanchez</a>,<a href = 'https://www.linkedin.com/in/emilianagallegos/'> Emiliana Gallegos </a>,<a href = 'https://www.linkedin.com/mwlite/in/zackery-snaidman-b1abaa133'> Zackery Snaidman</a>,<a href = 'https://twitter.com/itsevev'> Eve Vanagas</a>,<a href = 'https://www.linkedin.com/in/anniston-mcmahan-6a4b20107/'> Anniston McMahan</a>,<a href = 'https://www.instagram.com/jacobecker/'> Jacob Becker</a>, <a href = 'https://www.linkedin.com/in/chandler-l-hommedieu-8b5669197/'> Chandler L`Hommedieu</a>, <a href = 'https://www.linkedin.com/in/amelia-minkin-387742189/'> Amelia S. Minkin</a>, <a href = 'https://www.linkedin.com/in/sonia-vargas-80a505150/'> Sonia Vargas</a>, and other members of the University of Florida Fall 2020 Election Data Science class!"),
             br(),
             br(),
             br(),
             h1("FAQ", align = "center"),
             br(),
             p(strong("Q: What is this app?")),
             p("A: This app visualizes all the ballot drop-off and early-voting locations in the state of Florida. We built it to help make early voting safer and easier for Florida voters."),
             br(),
             p(strong("Q: Who built this app?")),
             p("A: This app is a collaborative effort between members of the University of Florida Election Sciences Team and students taking the University of Florida's Fall 2020 Election Data Science class"),
             br(),
             p(strong("Q: How long will this app be available?")),
             p("A: This app will be available until the end of early voting in Florida, which, in some counties, is November 2nd. After that, it will be archived on the project lead's GitHub page"),
             br(),
             p(strong("Q: My county election officials have different information than advertised by this app. Who's correct?")),
             p("A: Trust your local elections officials! This app was made by volunteers hoping to help make voters' lives a little easier. We don't claim, or intend, to supercede information provided by bona fide election officials. (If you do catch an error though---contact us so we can correct it!)"),
             br(),
             p(strong("Q: Why is the third interface labeled 'experimental?'")),
             p("A: We labeled it 'experimental' so that users would exercise the appropriate amount of caution when using this feature. It only provides distances 'as the crow flies.' Sometimes, it may be faster to travel to locations that are further away because of roads and traffic. These points are meant to suggest options to people. They should exercise their discretion when choosing which site is best for them."),
             br(),
             p(strong("Q: This app has all of the ballot drop-off and early-voting locations in Florida?")),
             p("A: That's the hope! IF we appear to be missing a location, please reach out and let us know!"),
             br(),
             p(strong("Q: How did you make this app?")),
             p("A: This app was programmed in R and built in Shiny."),
             br(),
             p(strong("Q: Can I support your efforts somehow?")),
             p("A: You can support us best by voting! And second best by sharing this app with others so that they can learn where they can drop-off their ballots and/or vote early."),
             br(),
             br(),
             HTML("<center><p>Comments? Questions? Spot an error? Let us know by e-mailing <a href = 'mailto: plicari13@ufl.edu'> Peter Licari.</a></center>"),
             br(),
             br()
             ),
    footer = em("This is a project constructed to be a service for Florida voters to help them vote safely this November. It is not intended to replace information made available by State or County elections officials.
    Please visit the 'about' page to get a list of the project's contributors.")) 

    
    



# Define server logic required to draw a histogram
server <- function(input, output, session) {


output$map3 <- renderLeaflet({
    leaflet() %>% addTiles() %>%
        addPolygons(data = fl_cnty_bdrs, group = "Main1")
})

output$map2 <- renderLeaflet({
    gps_tmp <- subset(gps_points, County == input$county) %>%
        filter(type %in% input$check1)
    leaflet() %>% addTiles() %>%
        addPolygons(data = subset(fl_cnty_bdrs, name == input$county)) %>%
        addMarkers(data = gps_tmp,
                   popup =  paste("<strong>Location Name:</strong>", gps_tmp$Location, "<br>",
                                  "<strong>Address:</strong>", gps_tmp$Address, "<br>",
                                  "<strong>County:</strong>", gps_tmp$County, "<br>","<br>",
                                  "<strong>Location Type:</strong>",gps_tmp$type, "<br>",
                                  "<strong>Dates Available:</strong>", gps_tmp$Dates.Available, "<br>")) %>%
        setView(lat = st_coordinates(st_centroid(subset(fl_cnty_bdrs, name == input$county)))[[2]],
                lng = st_coordinates(st_centroid(subset(fl_cnty_bdrs, name == input$county)))[[1]],
                zoom = 10)
})

output$map1 <- renderLeaflet({
    leaflet() %>% addTiles() %>%
        addPolygons(data = fl_cnty_bdrs) %>%
        addMarkers(data = gps_points, popup = paste("<strong>Location Name:</strong>", gps_points$Location, "<br>",
                                                    "<strong>Address:</strong>", gps_points$Address, "<br>",
                                                    "<strong>County:</strong>", gps_points$County, "<br>","<br>",
                                                    "<strong>Location Type:</strong>",gps_points$type, "<br>",
                                                    "<strong>Dates Available:</strong>", gps_points$Dates.Available, "<br>"
        ))
})

observeEvent(
    eventExpr = input$map1_zoom, {
        if(input$map1_zoom < 10){
            leafletProxy(mapId = "map1", 
                         session = session) %>%
                clearMarkers() 
        } else {
            leafletProxy(mapId = "map1", 
                         session = session) %>%
                addMarkers(data = gps_points, popup = paste("<strong>Location Name:</strong>", gps_points$Location, "<br>",
                                                            "<strong>Address:</strong>", gps_points$Address, "<br>",
                                                            "<strong>County:</strong>", gps_points$County, "<br>","<br>",
                                                            "<strong>Location Type:</strong>",gps_points$type, "<br>",
                                                            "<strong>Dates Available:</strong>", gps_points$Dates.Available, "<br>"
                ))
        }
        
        
    })


observeEvent(
    eventExpr = input$map3_click, {
        click <- input$map3_click
        
        clicksf <- st_as_sf(tibble::tribble(~longitude, ~latitude,
                                            click$lng, click$lat)
                            , coords = c("longitude","latitude"),
                            crs = 4326)
        fl_cnty_crs <- fl_cnty_bdrs %>% sf::st_set_crs(4326)
        
        tmp <- st_contains(x = fl_cnty_crs , y = clicksf, sparse = F)
        tmp1 <- cbind(x = tmp, name = fl_cnty_bdrs$name)
        
        fl_test <- fl_cnty_bdrs %>%
          full_join(tmp1, copy = TRUE) %>%
          filter(V1 == "TRUE")
        
        markers_filt <- dplyr::filter(gps_points, County == fl_test$name)%>%
            filter(type %in% input$check3)
        
        gps_points_sf <-st_as_sf(markers_filt, coords = c("longitude","latitude"), crs = 4326)
        
        tmp2 <- st_distance(x = clicksf, y = gps_points_sf)
        tmp2 <- t(tmp2)
        
        tmp3 <- cbind(markers_filt, tmp2)
        tmp3 <- tmp3 %>% dplyr::mutate(tmp2 = as.double(tmp2/1609.34)) %>%
          dplyr::mutate(tmp2 = round(tmp2, digits = 1)) 

        leafletProxy('map3', session = session) %>% 
            clearGroup(group = "Main1") %>%
            clearGroup(group = "Main") %>%
            clearGroup(group = "markers") %>%
            clearGroup(group = "click") %>%
            addMarkers(lng = click$lng, lat = click$lat, group = "click", icon = homeicon) %>%
            addPolygons(data = fl_test, layerId = "Main") %>%
            addMarkers(data = markers_filt, group = "markers",
                     popup = paste("<strong>Location Name:</strong>", markers_filt$Location, "<br>",
                                   "<strong>Address:</strong>", markers_filt$Address, "<br>",
                                   "<strong>County:</strong>", markers_filt$County, "<br>","<br>",
                                   "<strong>Location Type:</strong>",markers_filt$type, "<br>",
                                   "<strong>Dates Available:</strong>", markers_filt$Dates.Available, "<br>"),
                     label = paste0("Approximate Distance From Point:",
                                    tmp3$tmp2, " miles")) %>%
          setView(lng = click$lng, lat = click$lat, zoom = 10)
        
    })


observeEvent(
    eventExpr = input$submit, {
        leafletProxy('map3', session = session) %>%
            clearGroup(group = "Main1") %>%
        addPolygons(data = fl_cnty_bdrs, group = "Main1") %>%
          clearGroup(group = "Main") %>%            
          clearGroup(group = "markers") %>%
          clearGroup(group = "click") %>%
        setView(lng = -81.760254, lat =27.994402 , zoom = 6)




})



}

# Run the application 
shinyApp(ui = ui, server = server)
